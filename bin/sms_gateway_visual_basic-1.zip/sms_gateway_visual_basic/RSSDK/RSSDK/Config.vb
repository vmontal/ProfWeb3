﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text

Namespace RS
    Public Class Config
        Public Const HOSTNAME As String = "adminsms.aruba.it"
        Public Const USERNAME As String = "your@login"
        Public Const PASSWORD As String = "yourpassword"
        Public Const DEFAULT_PORT As Integer = 80
        Public Const PROXY As String = ""
        Public Const PROXY_PORT As Integer = 8080
    End Class
End Namespace
